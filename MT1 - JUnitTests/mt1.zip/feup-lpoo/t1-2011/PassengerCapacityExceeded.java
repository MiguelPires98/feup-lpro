
public class PassengerCapacityExceeded extends Exception {

}
