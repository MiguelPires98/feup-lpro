
public abstract class ServicoABordo {
	protected String descricaoServico;

	public ServicoABordo() {}

	public String getDescricaoServico() {
		return descricaoServico;
	}
}
