
public class Carruagem {
	protected int lugares;
	
	public int getNumLugares() {
		return lugares;
	}

	public void setNumLugares(int lugares) {
		this.lugares = lugares;
	}

	public Carruagem(int lugares) {
		super();
		this.lugares = lugares;
	}
}
