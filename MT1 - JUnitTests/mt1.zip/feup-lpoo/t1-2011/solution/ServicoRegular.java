
public class ServicoRegular extends ServicoABordo {

	public ServicoRegular() {
		this.descricaoServico = "Servico regular.";
	}

}
