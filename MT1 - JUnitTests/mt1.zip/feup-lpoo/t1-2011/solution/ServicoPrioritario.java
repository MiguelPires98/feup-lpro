
public class ServicoPrioritario extends ServicoABordo {

	public ServicoPrioritario() {
		this.descricaoServico = "Servico prioritario.";
	}

}
