
public class ServicoSemEnjoos extends ServicoABordo {

	public ServicoSemEnjoos() {
		this.descricaoServico = "Servico sem enjoos.";
	}

}
