package geometria;

public abstract class Countable {
	Countable() {}

	abstract int count();
}
