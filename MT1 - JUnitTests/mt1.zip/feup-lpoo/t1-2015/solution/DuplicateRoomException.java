
public class DuplicateRoomException extends Exception {
}
