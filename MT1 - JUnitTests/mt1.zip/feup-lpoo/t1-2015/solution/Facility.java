
public interface Facility {
	public String getName();
	public boolean canEnter(User u);
}
