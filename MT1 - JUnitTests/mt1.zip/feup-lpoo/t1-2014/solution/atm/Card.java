package atm;

public class Card {
	private int number;
	
	public Card(int number) {
		this.number = number;
	}
	
	public int getNumber() {
		return number;
	}
}
