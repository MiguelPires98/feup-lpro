package atm;

public interface Countable {

	public int count();
}
