package circuits;

public class CycleException extends Exception {

}
