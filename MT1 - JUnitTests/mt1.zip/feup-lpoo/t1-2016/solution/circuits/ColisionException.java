package circuits;

public class ColisionException extends Exception {
	
}
