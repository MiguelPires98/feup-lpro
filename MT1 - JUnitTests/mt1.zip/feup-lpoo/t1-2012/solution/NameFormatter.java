
public abstract class NameFormatter {
	protected char separator;

	public NameFormatter() {
	}
	
	public char getSeparator() {
		return separator;
	}
}
