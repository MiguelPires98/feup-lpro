
public class DOSFormatter extends NameFormatter {

	public DOSFormatter() {
		separator = '\\';
	}

}
