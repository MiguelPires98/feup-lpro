
public class UnixFormatter extends NameFormatter {

	public UnixFormatter() {
		separator = '/';
	}

}
